from ultralytics import YOLO
from ultralytics import NAS
from ultralytics import RTDETR
from ultralytics import YOLOWorld

from pathlib import Path
from typing import Dict, Any


# yolo_nas_s.pt / yolo_nas_m.pt / yolo_nas_l.pt
# rtdetr-l.pt / rtdetr-x.pt
# yolov8s-worldv2.pt / yolov8m-worldv2.pt / yolov8l-worldv2.pt / yolov8x-worldv2.pt
# yoloe-s.pt

# yolov10n.pt / yolov10s.pt / yolov10m.pt / yolov10b.pt / yolov10l.pt
# yolov8n.pt / yolov8s.pt / yolov8m.pt / yolov8l.pt / yolov8x.pt
# yolov5n.pt / yolov5s.pt / yolov5m.pt / yolov5l.pt / yolov5x.pt

# 模型配置清单（可扩展）
MODEL_CONFIGS = {    

    # YOLOv8-World 系列
    # "yolov8s-worldv2.pt": {"name_suffix": "v8s_world", "batch": 64},
    # "yolov8m-worldv2.pt": {"name_suffix": "v8m_world", "batch": 48},
    # "yolov8l-worldv2.pt": {"name_suffix": "v8l_world", "batch": 32},
    # "yolov8x-worldv2.pt": {"name_suffix": "v8x_world", "batch": 24},
    
    # RT-DETR 系列
    # "rtdetr-l.pt": {"name_suffix": "rtdetr_l", "batch": 4},
    "rtdetr-x.pt": {"name_suffix": "rtdetr_x", "batch": 8},

    # YOLOE 系列
    # "yoloe-s.pt": {"name_suffix": "yoloe_s", "batch": 64},
    
}


def train_model(
    data_yaml: str,
    model_cfg: Dict[str, Any],
    base_output_dir: str = "/data/lizhi/yolo/yolo_train_results",
    epochs: int = 150,
    imgsz: int = 640,
    device: str = "0"
) -> str:
    """增强型训练函数"""
    # 生成唯一实验名称
    model_name = Path(model_cfg["model_file"]).stem
    experiment_name = f"tooth_defect_{model_cfg['name_suffix']}"
    
    # 创建模型专属输出目录
    output_dir = Path(base_output_dir) / model_name
    output_dir.mkdir(parents=True, exist_ok=True)
    
    try:
        # 初始化模型
        model = YOLO(model_cfg["model_file"])
                
        if "world" in model_cfg["model_file"]:
            model = YOLOWorld(model_cfg["model_file"])
        
        if "rtdetr" in model_cfg["model_file"]:
            model = RTDETR(model_cfg["model_file"])

        if "nas" in model_cfg["model_file"]:
            model = NAS(model_cfg["model_file"])

        # 训练参数配置
        train_args = {
            "data": data_yaml,
            "epochs": epochs,
            "imgsz": imgsz,
            "batch": model_cfg["batch"],
            "name": experiment_name,
            "project": str(output_dir),
            "device": device,
            "workers": 8,
            "patience": 50,
            "save_period": 20,
            "exist_ok": True,
            "augment": True,
            "flipud": 0.5,
            "fliplr": 0.5,
            "mosaic": True,
            "cos_lr": True if "v10" in model_name else False,  # YOLOv10专用配置
            "label_smoothing": 0.1 if "nas" in model_name else 0.0  # NAS专用配置
        }
        
        # 执行训练
        results = model.train(**train_args)
        
        # 返回最佳模型路径
        best_model = output_dir / "weights" / "best.pt"
        print(f"✅ Training completed for {model_name}")
        return str(best_model)
        
    except Exception as e:
        print(f"❌ Training failed for {model_name}: {str(e)}")
        return ""

if __name__ == "__main__":
    data_yaml_path = "/data/lizhi/yolo/yolo_dataset/dataset.yaml"
    base_output_dir = "/data/lizhi/yolo/yolo_train_results"
    
    # 遍历所有模型配置
    for model_file, cfg in MODEL_CONFIGS.items():
        full_cfg = {"model_file": model_file, **cfg}
        train_model(
            data_yaml=data_yaml_path,
            model_cfg=full_cfg,
            base_output_dir=base_output_dir,
            epochs=150,
            imgsz=640,
            device="0"
        )
